<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?= (isset($pageTitle) ? $pageTitle : '') ?></title>
    <base href="http://<?= $_SERVER['SERVER_ADDR'] . str_replace('public/index.php', '', $_SERVER['SCRIPT_NAME']) ?>">
    <link rel="stylesheet" href="public/css/app.css">
</head>
<body>
<div class="container">
    <?php echo $pageContent ?>
</div>
</body>
</html>
