<?php 

namespace App\Controllers;

class Controller {

    protected $model;
    protected $modelName;
    protected $viewpath = "Views/";

    public function __construct()
    {
        if($this->modelName != NULL) {
            $this->model = new $this->modelName();
        }
    }

    public function index() {

        $this->render('index', ['pageTitle' => 'Homepage', 'controller' => __CLASS__]);
    }

    public function render($path, $variables = []) {
        ob_start();

        extract($variables);

        require_once ROOT . "$this->viewpath/$path.php";

        $pageContent = ob_get_clean();

        require_once ROOT . "$this->viewpath/layout.php";
    }

    public function redirect($file)
    {
        header("Location: $file");
        exit();
    }
}