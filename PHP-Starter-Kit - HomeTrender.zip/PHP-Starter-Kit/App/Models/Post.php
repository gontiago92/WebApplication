<?php


namespace App\Models;


class Post extends Model
{
    protected $table = "articles";

    public function insert(array $values)
    {
        $query = $this->pdo->prepare("INSERT INTO {$this->table} SET title = ?, introduction = ?, content = ?, created_at = NOW()");

        // On exécute la requête en précisant le paramètre :id
        $query->execute($values);

    }
}