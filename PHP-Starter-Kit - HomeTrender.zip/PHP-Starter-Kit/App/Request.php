<?php

namespace App;

class Request {
    
    public $url;
    public $controller = "Controller";
    public $method = "index";
    public $params = [];

    public function __construct($url)
    {
        $this->url = $url;
    }

}