function showMenu(id, link) {
    closeActiveElements()
    link.classList.add('active')
    document.querySelector(id).classList.add('active')
    document.querySelector('.container').classList.add('active')
}

function closeActiveElements() {
    let activeElement = document.querySelector('.sidenav-expanded.active')
    let activeTab = document.querySelector('nav.sidenav a.active')

    if (activeElement)
        activeElement.classList.remove('active')

    if (activeTab)
        activeTab.classList.remove('active')
}

function closeAll() {
    closeActiveElements()
    document.querySelector('.container').classList.remove('active')
}