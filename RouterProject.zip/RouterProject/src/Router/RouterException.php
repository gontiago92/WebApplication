<?php


namespace App\Router;


class RouterException extends \Exception
{

}