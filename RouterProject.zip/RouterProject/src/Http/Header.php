<?php


namespace App\Http;


class Header
{
    public function set($header)
    {
        header($header);
    }
}