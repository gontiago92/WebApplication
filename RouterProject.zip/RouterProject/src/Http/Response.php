<?php


namespace App\Http;


class Response
{
    public $content;
    public $headers;

    public function __construct()
    {
        $this->headers = new Header();
    }

    /**
     * @param mixed $content
     */
    public function setContent($content): void
    {
        $this->content = $content;
    }

    /**
     * @return mixed
     */
    public function getContent()
    {
        return 'fewfwe';
    }

    public function send()
    {
        $this->getContent();
    }

}