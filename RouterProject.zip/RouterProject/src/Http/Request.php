<?php


namespace App\Http;


class Request
{
    public $request;
    public $query;
    public $server;

    public function __construct()
    {
        $this->request = $_POST;
        $this->query = new Query($_GET);
        $this->server = $_SERVER;
    }

    public function getMethod()
    {
        return $this->request['REQUEST_METHOD'];
    }

    public function getUrl()
    {
        return $this->request['REQUEST_URI'];
    }

}