<?php

namespace App\Controllers;

use App\Models\Post;

class PostsController extends Controller
{

    protected $modelName = Post::class;

    public function index() 
    {
        $posts = $this->model->findAll();

        $this->render('posts/index', compact('posts'));
    }

    public function show($id) 
    {

        $post = $this->model->find('post_id', $id);

        if($post) {
            return $this->render('posts/show', compact('post', 'id'));
        }

        $this->redirect('/404', ["message" => "The article with the id : $id doesn't seem to exist in the database !"]);
    }

}