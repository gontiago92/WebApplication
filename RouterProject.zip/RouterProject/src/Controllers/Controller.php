<?php

namespace App\Controllers;

use App\Models\Post;

class Controller 
{
    
    protected $viewpath = ROOT . "/views/";
    protected $modelName = Post::class;
    protected $model;

    public function __construct()
    {
        $this->model = new $this->modelName();
    }

    public function render($path, $variables = []) 
    {
        ob_start();
    
        extract($variables);
    
        require $this->viewpath . "$path.php";
    
        $pageContent = ob_get_clean();
    
        require $this->viewpath . "layout.php";
    }

    public function redirect($path)
    {
        header("Location: $path");
        exit();
    }

}