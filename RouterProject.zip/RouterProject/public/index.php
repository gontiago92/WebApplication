<?php
/*
use App\Http\Response;
use App\Http\Request;

require '../vendor/autoload.php';

$request = new Request();

$name = $request->query->get('name', 'DefaultName');

$response = new Response();
$response->headers->set('Content-Type: text/html; charset=utf-8');

$response->setContent(sprintf('Hello %s', htmlspecialchars($name, ENT_QUOTES)));

$response->send();
*/

use App\Router\Router;
use App\Router\RouterException;

define('ROOT', dirname(__DIR__));

require ROOT . '/vendor/autoload.php';

$router = new Router($_SERVER['REQUEST_URI']);

$router->get('/', "Posts#index");
$router->get('/about', function() { echo "About page"; });
$router->get('/contact', function() { echo "Contact page"; });
$router->get('/posts', "Posts#index");
$router->get('/posts/:id', "Posts#show");
$router->post('/posts/:id', "Comment#create");

$router->get('/404', "ErrorHandler#notFound");

try {
    $router->run();
} catch(RouterException $e) {
    die($e->getMessage());
}
?>
