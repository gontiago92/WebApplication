<h1>Liste de tous les posts</h1>

<?php foreach ($posts as $post): ?>

    <a href="/posts/<?= $post->post_id ?>"><?= $post->title ?></a>

<?php endforeach; ?>