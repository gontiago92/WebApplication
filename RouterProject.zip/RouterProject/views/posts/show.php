<h1> #<?= $post->post_id . " - " . $post->title ?></h1>
<p><?= $post->content ?></p>