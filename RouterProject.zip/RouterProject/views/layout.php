<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Router Project</title>
</head>
<body>
    <nav>
        <a href="/">Homepage</a>
        <a href="/about">About</a>
        <a href="/contact">Contact</a>
        <a href="/posts">Posts</a>
    </nav>

    <?= $pageContent ?>
</body>
</html>