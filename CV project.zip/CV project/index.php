<?php

/*
if(isset($_POST['createFile'])) {
    //echo "Filename : " . $_POST['filename'];
    //echo "File ext : " . $_POST['extension'];
    $acceptedExtensions = ['txt', 'json'];

    if(!in_array($_POST['extension'], $acceptedExtensions)) {
        die("The chosen extension is not valid ! <a href=''>Reload</a>");
    }

    if(!empty($_POST['filename'])) {
        $filename = $_POST['filename'] . '.' . $_POST['extension'];
    } else {
        die("You need to name your file ! <a href=''>Reload</a>");
    }


    if (!$handle = fopen($filename, 'a')) {
        echo "Impossible d'ouvrir le fichier ($filename)";
        exit;
    }

    $txt = "John Doe\n";
    fwrite($handle, $txt);
    $txt = "Jane Doe\n";
    fwrite($handle, $txt);

    fclose($handle);
}*/

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Testing file writing and reading</title>
</head>
<body>
    <h1>PHP - Testing file writing and reading</h1>

    <form method="GET">
        <button type="submit" name="makeReq">Request info</button>
    </form>

    <form method="POST">
        <input type="text" name="filename" placeholder="Filename here">
        
        <select name="extension">
            <option value="txt">Plain Text (.txt)</option>
            <option value="json">JSON (.json)</option>
        </select>
        
        <button type="submit" name="createFile">Create file</button>
    </form>


    <script>

    var xhr = new XMLHttpRequest(),
    jsonArr,
    method = "POST",
    jsonRequestURL = "lib/JSON/";

    xhr.open(method, jsonRequestURL, true);
    xhr.onreadystatechange = function()
    {
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            // we convert your JSON into JavaScript object
            jsonArr = JSON.parse(xhr.responseText);

            // we add new value:
            jsonArr.push({"nissan": "sentra", "color": "green"});

            // we send with new request the updated JSON file to the server:
            xhr.open("POST", jsonRequestURL, true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            // if you want to handle the POST response write (in this case you do not need it):
            // xhr.onreadystatechange = function(){ /* handle POST response */ };
            xhr.send("jsonTxt="+JSON.stringify(jsonArr));
            // but on this place you have to have a server for write updated JSON to the file
        }
    };
    xhr.send(null);
    </script>
</body>
</html>