const personSearch = document.getElementById('person_search')
const feedback = document.querySelector('.feedback')
let people = []



let ajax = function (url) {
    // On renvoie une promesse qui prend en paramettre une fonction 
    // avec 2 paramètres, le callback de succès et d'erreur
    return new Promise(function (resolve, reject) {
        // Le reste du code ressemble à la méthode précédente
        let req = new XMLHttpRequest()
        req.open('GET', url, true)
        req.onreadystatechange = function (aEvt) {
            if (req.readyState == 4) {
                if(req.status == 200)
                    resolve(req.responseText)
                else
                    reject(req)
            }
        };
        req.send(null)
    })
}
  
// L'appel à la fonction peut se faire de cette manière là
ajax('person_lookup.php')
.then(function (response) {
    // Le serveur a correctement répondu
    //console.log(response)
    people = JSON.parse(response)
}).catch(function (req) {
    // Le serveur n'a pas répondu comme attendu
    console.error(req)
})

personSearch.addEventListener('keyup', () => {

    if(personSearch.value.length > 0) {

        feedback.classList.add('active')
        personSearch.classList.add('active')

        let users = people.filter(function(person) {

            if(person.name.toLowerCase().indexOf(personSearch.value.toLowerCase()) > -1) {
                return person
            }
                
        });

        if(users.length > 0) {

            let result = ''
            users.forEach(element => {
                if(element.name != "Administrator") {
                    result += `<li><a href="#"><img width="50px" src="https://images.unsplash.com/photo-1526498460520-4c246339dccb?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80">${element.name}</a></li>`
                }
            });

            if(result != '')
                feedback.innerHTML = result
            else
                feedback.innerHTML = "<li class='noresult'>Aucun résultat</li>"
        } else {
            feedback.innerHTML = "<li class='noresult'>Aucun résultat</li>"
        }
    } else {
        feedback.classList.remove('active')
        personSearch.classList.remove('active')
        feedback.innerHTML = ''
    }


})


/*
personSearch.addEventListener('keyup', (e) => {

    if(personSearch.value.length > 0) {

        feedback.classList.add('active')
        personSearch.classList.add('active')

        const xml = new XMLHttpRequest();
        xml.onreadystatechange = function() {
            if( xml.readyState==4 && xml.status==200 ){
                let results = JSON.parse(xml.responseText)
                
                if(results.length > 0) {
                    let users = ''
                    results.forEach(element => {
                        if(element.name != "Administrator") {
                            users += `<li><a href="#"><img width="50px" src="https://images.unsplash.com/photo-1526498460520-4c246339dccb?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80">${element.name}</a></li>`
                        }
                    });
    
                    feedback.innerHTML = users
    
                } else {
                    feedback.innerHTML = "<li class='noresult'>Aucun résultat</li>"
                }
               
            }
        };

        xml.open("POST", "person_lookup.php", false);
        xml.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xml.send("name=" + personSearch.value);

    } else {
        feedback.classList.remove('active')
        personSearch.classList.remove('active')
        feedback.innerHTML = ''
    }

})*/

personSearch.addEventListener('click', (e) => {
    e.stopPropagation()
})


document.addEventListener('click', (e) => {
    feedback.classList.remove('active')
    personSearch.classList.remove('active')
    personSearch.value = ''
    feedback.innerHTML = ''
})
