<?php 

$pdo = new PDO("mysql:host=127.0.0.1;dbname=bams", "root", "root", 
[
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"
]);

$req = $pdo->prepare("SELECT * FROM users");
$req->execute();
$users = $req->fetchAll(PDO::FETCH_ASSOC);

header("content-type:application/json");

echo json_encode($users);