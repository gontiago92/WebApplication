<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BAMS</title>
    <link rel="stylesheet" href="css/app.css">
</head>
<body>

    <header>
        <a class="title" href="#">Brink's Access Management</a>
    </header>
    <nav>
        <a href="#">Accueil</a>
        <a href="#">Création de badges</a>
        <a href="#">Recherche</a>
        <a href="#">Préparation de badge</a>
        <a href="#">Aide</a>
    </nav>

    <div class="container">
        <div class="person_search">
            <input type="search" name="name" id="person_search" placeholder="Rechercher" autocomplete="off">
            <ul class="feedback"></ul>
        </div>
    </div>
    
    <script src="js/app.js"></script>
</body>
</html>