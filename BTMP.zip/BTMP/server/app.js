var express = require("express")
var app = express()
var http = require("http").Server(app)

app.use(express.static("public"))

app.set('views', './views') // specify the views directory
app.set("view engine", "pug")

app.get("/", function(req, res) {
    res.render("index")
})

http.listen(3000, function() {
    console.log("listening on *:3000")
})