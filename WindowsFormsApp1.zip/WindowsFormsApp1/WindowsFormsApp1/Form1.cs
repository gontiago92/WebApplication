﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{

    public partial class WebServer : Form
    {
        public string envPath = System.Environment.GetEnvironmentVariable("USERPROFILE") + "\\Sites\\local.dev\\";

        public WebServer()
        {
            InitializeComponent();
            Displaynotify();
        }

        private void OpenProcess(string fileName, string arguments = null)
        {
            Process myProcess = new Process();

            myProcess.StartInfo.UseShellExecute = false;
            // You can start any process, HelloWorld is a do-nothing example.
            myProcess.StartInfo.FileName = fileName;
            myProcess.StartInfo.Arguments = @arguments;
            myProcess.StartInfo.CreateNoWindow = true;
            myProcess.Start();
        }

        private void KillProcess(string processName)
        {
            Process[] processes = Process.GetProcessesByName(processName);

            foreach (Process process in processes)
            {
                process.Kill();
            }
        }

       

        private void Form1_Load(object sender, EventArgs e)
        {
            Displaynotify();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            OpenProcess("cmd.exe", "/c " + envPath + "env\\php\\php -S 127.0.0.1:80 -t " + envPath.Replace("\\", "/"));
            button1.Enabled = false;
            button3.Enabled = true;
            Color success = Color.FromArgb(46, 204, 113);
            checkBox1.ForeColor = success;
            checkBox1.Checked = true;
            checkBox1.Text = "PHP Status : running... " + envPath.Replace('\\', '/');
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            OpenProcess("cmd.exe", "/c " + envPath + "env\\mysql\\bin\\mysqld --console");
            button2.Enabled = false;
            button4.Enabled = true;
            checkBox2.Checked = true;
            checkBox2.Text = "MySQL Status : running...";
        }

        private void button3_Click(object sender, EventArgs e)
        {

            KillProcess("php");
            button1.Enabled = true;
            button3.Enabled = false;
            checkBox1.Checked = false;
            checkBox1.Text = "PHP Status : not running";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            KillProcess("mysqld");
            button2.Enabled = true;
            button4.Enabled = false;
            checkBox2.Checked = false;
            checkBox2.Text = "MySQL Status : not running";
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            KillProcess("php");
            KillProcess("mysqld");
            Application.Exit();
        }


        protected void Displaynotify()
        {
            try
            {
                notifyIcon1.Icon = new Icon(Path.GetFullPath(@"image\graph.ico"));
                notifyIcon1.Text = "Export Datatable Utlity";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Welcome Devesh omar to Datatable Export Utlity";
                notifyIcon1.BalloonTipText = "Click Here to see details";
                notifyIcon1.ShowBalloonTip(100);
            }
            catch (Exception ex)
            {
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show("you clicked on notifyicon | More features will be available soon !");
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}