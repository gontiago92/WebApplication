<?php

include(__DIR__ . "/dashboard/index.php");

?>