
<?php

$projects = scandir(dirname(__DIR__) . "/projects");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Server</title>
    <!-- CSS only -->
    <!--<link rel="stylesheet" href="/dashboard/bootstrap/css/bootstrap.css">-->
    <link rel="stylesheet" href="/dashboard/assets/css/app.css">
</head>
<body>


<nav class="sidenav">
    <ul>
        <li class="title"><img src="/dashboard/assets/images/app.svg" width="40px" alt=""></li>
        <li><a href="#" class="active"><i class="fa fa-inbox fa-2x"></i></a></li>
        <li><a href="#"><i class="fab fa-php fa-2x"></i></a></li>
        <li><a href="#"><i class="fa fa-cogs fa-2x"></i></a></li>
    </ul>
</nav>

<div class="wrapper">


<header>
    <div class="titleHeader">
        <h1>All projects</h1>
        <a href="#" class="btn btn-success"><i class="fa fa-plus"></i> New project</button>
    </div>
</header>

<div class="container row">
  <div class="col"><h3>All projects</h3></div>
  <div class="col"><h3>fezfze</h3></div>
</div>


<div class="row">

        <?php foreach($projects as $project): ?>
            <?php if($project != "." && $project != ".."): ?>

                <div class="card">
                    <div class="card-header">
                        <div class="card-image">
                            <img src="/dashboard/assets/images/globe.svg" alt="">
                        </div>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><i class="fa fa-folder mr-2"></i><a href="<?= "projects/" . $project ?>"><?= $project ?></a></h5>
                        <p class="card-title"></p>
                    </div>
                </div>

            <?php endif; ?>
        <?php endforeach; ?>

</div>


<script src="/dashboard/assets/js/app.js"></script>
</body>
</html>