// RANDOM COLOR generated automatically
var randColor = '#' + Math.floor(Math.random()*16777215).toString(16)
// RANDOM SELECTION from array
var colors = ["#3498db", "#2ecc71", "#e74c3c", "#1abc9c"];

function getRandColor(array) {
	var val = Math.floor(Math.random() * array.length)
 	return array[val];
}

var cardImages = document.querySelectorAll(".card-image")

//document.body.style.backgroundColor = bgcolor

cardImages.forEach(element => {
    var bgcolor = '#' + Math.floor(Math.random()*16777215).toString(16)
  element.style.backgroundColor = bgcolor
})