<?php

use App\Request;
use App\Router\Router;

define('ROOT', str_replace('public/index.php', '', $_SERVER['SCRIPT_FILENAME']));

require ROOT . '/App/App.php';

App::init();

$request = new Request($_SERVER['REQUEST_URI']);
$url = Router::parse($request->url);

//debug($request);

debug(App::process($request, $url));

