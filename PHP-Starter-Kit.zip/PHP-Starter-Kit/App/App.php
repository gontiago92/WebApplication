<?php

use App\Controllers\Controller;
use App\Request;

class App {

    static $controller;
    static $method;
    static $args = [];

    public static function init() {
        require_once ROOT . "App/init.php";
    }

    public static function process(Request $request, $url) {

        self::$controller = $request->controller;
        self::$method = $request->method;
        self::$args = $request->params;

        if(isset($url[0])) {
            if(class_exists('App\Controllers\\' . $url[0] . 'Controller')) {
                self::$controller = ucfirst($url[0]) . 'Controller';
                unset($url[0]);
            }
        }

        self::$controller = 'App\Controllers\\' . self::$controller;

        if(isset($url[1])) {
            if(method_exists(self::$controller, 'index')) {
                
            }
        }
    }

}