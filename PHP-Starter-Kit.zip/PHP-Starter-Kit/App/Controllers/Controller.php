<?php 

namespace App\Controllers;

class Controller {
    public function __construct()
    {
        echo __CLASS__;
    }

    public function index() {
        
    }
}