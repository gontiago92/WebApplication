<?php

namespace App\Controllers;

class PostsController extends Controller {
    
}