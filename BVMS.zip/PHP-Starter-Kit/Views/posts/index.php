<h1>Lista de todos os artigos (homepage)</h1>

<div class="row">
    <?php foreach($articles as $article): ?>

    <div class="card">
        <a class="card-image-link" href="post/show/<?= $article->id ?>"><div class="card-image"></div></a>
        <div class="card-body">
            <div class="postinfo">
                <a href="#"><small>admin</small></a>
                <a href="#"><small>Category</small></a>
                <small><?= App::timeago($article->created_at, 'pt') ?></small>
            </div>
            <a href="post/show/<?= $article->id ?>" class="card-title-link">
                <h2 class="card-title"><?= $article->title ?></h2>
            </a>
            <p class="card-text"><?= $article->introduction ?></p>
            <a href="post/delete/<?= $article->id ?>" onclick="return window.confirm(`Êtes vous sur de vouloir supprimer cet article ?!`)">Supprimer</a>
        </div>
    </div>

    <?php endforeach; ?>
</div>