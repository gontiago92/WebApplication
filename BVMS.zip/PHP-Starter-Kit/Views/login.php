<form action="">
    <div>
        <label for="">Identifiant</label>
        <input type="text" class="form-control" name="username" placeholder="Votre identifiant">
    </div>

    <div>
        <label for="">Mot de passe</label>
        <input type="password" class="form-control" name="password" placeholder="Votre mot de passe">
    </div>

    <button class="btn primary" type="submit">Me connecter</button>
</form>