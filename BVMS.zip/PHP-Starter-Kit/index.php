<?php
include __DIR__ . "/public/index.php";

/*
echo __DIR__;
die($_SERVER["REQUEST_URI"]);

$request_uri = __DIR__ . $_SERVER["REQUEST_URI"];

if (file_exists($request_uri)) {
    return false;
} else {
    include __DIR__ . "/public/index.php";
}

?>

<h1>Welcome to php</h1>
*/
