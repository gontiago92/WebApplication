<?php

require './App/App.php';

App::init();

App::process();

