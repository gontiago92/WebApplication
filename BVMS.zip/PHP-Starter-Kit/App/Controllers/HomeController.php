<?php


namespace App\Controllers;

class HomeController extends Controller
{
    protected $modelName = \App\Models\Post::class;

    public function index()
    {
        $auth = new \App\Auth();
        if($auth->isLogged()) {
            $this->redirect('home/index');
        } else {
            $this->redirect('auth/login');
        }
        /**
         * 2. Affichage
         */

        //$this->render('home/index', ['pageTitle' => 'Homepage']);

    }
}