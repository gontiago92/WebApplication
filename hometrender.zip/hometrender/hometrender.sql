-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 10, 2020 at 03:05 AM
-- Server version: 5.7.30
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hometrender`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `post_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `author`, `message`, `post_id`, `created_at`) VALUES
(1, 'Unknown', 'Faucibus purus in massa tempor. Id aliquet risus feugiat in ante. Libero enim sed faucibus turpis in eu. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Amet tellus cras adipiscing enim eu turpis egestas pretium.', 1, '2020-08-08 22:59:05'),
(2, 'Daughtry', 'Faucibus purus in massa tempor. Id aliquet risus feugiat in ante. Libero enim sed faucibus turpis in eu. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Amet tellus cras adipiscing enim eu turpis egestas pretium.', 2, '2020-08-08 22:59:05'),
(3, 'Daughtry', 'Faucibus purus in massa tempor. Id aliquet risus feugiat in ante. Libero enim sed faucibus turpis in eu. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Amet tellus cras adipiscing enim eu turpis egestas pretium.', 1, '2020-08-08 22:59:05');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `author` varchar(255) NOT NULL,
  `status` enum('public','private') NOT NULL DEFAULT 'private',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `author`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Mon premier article', '<p>Faucibus purus in massa tempor. Id aliquet risus feugiat in ante. Libero enim sed faucibus turpis in eu. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Amet tellus cras adipiscing enim eu turpis egestas pretium.</p>\r\n<p>Aliquet bibendum enim facilisis gravida neque convallis a cras semper. Aliquet porttitor lacus luctus accumsan tortor posuere ac ut consequat. Nisi lacus sed viverra tellus in hac habitasse. In dictum non consectetur a. Nisl nunc mi ipsum faucibus. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Penatibus et magnis dis parturient montes. Quam vulputate dignissim suspendisse in est ante in nibh.</p>\r\n<p>Nunc aliquet bibendum enim facilisis gravida neque convallis. Mattis pellentesque id nibh tortor id aliquet. Venenatis lectus magna fringilla urna porttitor rhoncus. Nam at lectus urna duis convallis convallis tellus id. Non arcu risus quis varius quam quisque id diam vel. Neque laoreet suspendisse interdum consectetur libero id. Placerat duis ultricies lacus sed. Tristique et egestas quis ipsum suspendisse ultrices. Sit amet justo donec enim diam vulputate ut pharetra sit.</p>\r\n<p>Quis auctor elit sed vulputate mi. Interdum varius sit amet mattis vulputate. Posuere urna nec tincidunt praesent semper. Eget nunc scelerisque viverra mauris in aliquam sem. Auctor eu augue ut lectus arcu. Laoreet non curabitur gravida arcu ac. Urna porttitor rhoncus dolor purus non enim praesent elementum.</p>', 'John Doe', 'private', '2020-08-08 22:51:34', NULL),
(2, 'Deuxième article test', '<p>Faucibus purus in massa tempor. Id aliquet risus feugiat in ante. Libero enim sed faucibus turpis in eu. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Amet tellus cras adipiscing enim eu turpis egestas pretium.</p>\r\n<p>Aliquet bibendum enim facilisis gravida neque convallis a cras semper. Aliquet porttitor lacus luctus accumsan tortor posuere ac ut consequat. Nisi lacus sed viverra tellus in hac habitasse. In dictum non consectetur a. Nisl nunc mi ipsum faucibus. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Penatibus et magnis dis parturient montes. Quam vulputate dignissim suspendisse in est ante in nibh.</p>\r\n<p>Nunc aliquet bibendum enim facilisis gravida neque convallis. Mattis pellentesque id nibh tortor id aliquet. Venenatis lectus magna fringilla urna porttitor rhoncus. Nam at lectus urna duis convallis convallis tellus id. Non arcu risus quis varius quam quisque id diam vel. Neque laoreet suspendisse interdum consectetur libero id. Placerat duis ultricies lacus sed. Tristique et egestas quis ipsum suspendisse ultrices. Sit amet justo donec enim diam vulputate ut pharetra sit.</p>\r\n<p>Quis auctor elit sed vulputate mi. Interdum varius sit amet mattis vulputate. Posuere urna nec tincidunt praesent semper. Eget nunc scelerisque viverra mauris in aliquam sem. Auctor eu augue ut lectus arcu. Laoreet non curabitur gravida arcu ac. Urna porttitor rhoncus dolor purus non enim praesent elementum.</p>', 'Jane Doe', 'private', '2020-08-08 22:51:34', NULL),
(3, '3e article test', '<p>Faucibus purus in massa tempor. Id aliquet risus feugiat in ante. Libero enim sed faucibus turpis in eu. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Amet tellus cras adipiscing enim eu turpis egestas pretium.</p>\r\n<p>Aliquet bibendum enim facilisis gravida neque convallis a cras semper. Aliquet porttitor lacus luctus accumsan tortor posuere ac ut consequat. Nisi lacus sed viverra tellus in hac habitasse. In dictum non consectetur a. Nisl nunc mi ipsum faucibus. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Penatibus et magnis dis parturient montes. Quam vulputate dignissim suspendisse in est ante in nibh.</p>\r\n<p>Nunc aliquet bibendum enim facilisis gravida neque convallis. Mattis pellentesque id nibh tortor id aliquet. Venenatis lectus magna fringilla urna porttitor rhoncus. Nam at lectus urna duis convallis convallis tellus id. Non arcu risus quis varius quam quisque id diam vel. Neque laoreet suspendisse interdum consectetur libero id. Placerat duis ultricies lacus sed. Tristique et egestas quis ipsum suspendisse ultrices. Sit amet justo donec enim diam vulputate ut pharetra sit.</p>\r\n<p>Quis auctor elit sed vulputate mi. Interdum varius sit amet mattis vulputate. Posuere urna nec tincidunt praesent semper. Eget nunc scelerisque viverra mauris in aliquam sem. Auctor eu augue ut lectus arcu. Laoreet non curabitur gravida arcu ac. Urna porttitor rhoncus dolor purus non enim praesent elementum.</p>', 'Jane Doe', 'private', '2020-08-10 04:07:01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `created_at`) VALUES
(1, 'admin', 'admin', 'admin@hometrender.com', '2020-08-08 22:53:02'),
(2, 'gontiago92', '12345', 'gontiago92@test.com', '2020-08-08 22:53:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
