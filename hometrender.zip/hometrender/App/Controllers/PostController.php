<?php


namespace App\Controllers;

use App\Models\Comment;
use App\Models\Post;

class PostController extends Controller
{
    protected $modelName = Post::class;
    protected $viewpath = "Views";

    public function index()
    {

        $posts = $this->model->findAll();

        $this->render('posts/index', compact('posts'));
    }

    public function show($id)
    {

        $posts = $this->model->findAll();
        $post = $this->model->find($id);
        $commentModel = new Comment();

        $comments = $commentModel->findAllByPost($id);

        $this->render('posts/show', compact('posts', 'post', 'comments'));
    }
}