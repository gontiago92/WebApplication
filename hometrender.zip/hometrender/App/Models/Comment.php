<?php


namespace App\Models;

class Comment extends Model
{
    protected $table = "comments";

    /**
     * @param $post_id
     * @return array
     */
    public function findAllByPost($post_id)
    {
        $req = $this->pdo->prepare("SELECT * FROM {$this->table} WHERE post_id = ? ORDER BY created_at DESC");
        $req->execute([$post_id]);

        return $req->fetchAll();
    }

    /**
     * @param array $values
     */
    public function insert(array $values)
    {
        debug($values);
        $query = $this->pdo->prepare("INSERT INTO {$this->table} SET author = ?, message = ?, post_id = ?");
        $query->execute($values);
    }
}