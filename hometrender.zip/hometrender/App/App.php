<?php

use App\Request;
use App\Router\Router;

class App {

    private  static $request;
    private static $url;

    static $controller;
    static $method;
    static $args = [];

    public static function init() {
        require_once "./App/init.php";
        self::$request = new Request($_SERVER['REQUEST_URI']);
        self::$url = Router::parse(self::$request->url);
    }

    public static function process() {

        self::$controller = self::$request->controller;
        self::$method = self::$request->method;
        self::$args = self::$request->params;

        if(isset(self::$url[0])) {
            if(class_exists('App\Controllers\\' . self::$url[0] . 'Controller')) {
                self::$controller = ucfirst(self::$url[0]) . 'Controller';
                unset(self::$url[0]);
            }
        }

        self::$controller = 'App\Controllers\\' . self::$controller;

        if(isset(self::$url[1])) {
            if(method_exists(self::$controller, self::$url[1])) {
                self::$method =  self::$url[1];
                unset(self::$url[1]);
            }
        }

        self::$args = array_slice(self::$url, 0);

        call_user_func_array([new self::$controller, self::$method], self::$args);

    }

}