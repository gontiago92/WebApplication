<?php
define('ROOT', str_replace('\\', '/', str_replace('index.php', '', $_SERVER['SCRIPT_FILENAME'])));
//define('ROOT', dirname(__DIR__));

$GLOBALS['config'] = [
    "mysql" => [
        "host" => "localhost",
        "user" => "root",
        "pass" => "root",
        "dbname" => "hometrender"
    ]
];

spl_autoload_register(function($className) {

    $class = str_replace('\\', '/', $className);

    $file = ROOT . "$className.php";

    if(file_exists($file)) {
        require_once $file;
    }
});

function debug($var) {
    echo "<div class='container jumbotron my-4'><pre>" . print_r($var, true) . "</pre></div>";
}
