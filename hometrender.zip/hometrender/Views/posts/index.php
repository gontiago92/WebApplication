<h1>All posts</h1>

<?php foreach ($posts as $post): ?>

<div>

    <h3><?= $post->title ?></h3>
    <?= substr($post->content, 0, 120) . "..." ?>
    <a href="/post/show/<?= $post->id ?>">Read post</a>

</div>



<?php endforeach; ?>
