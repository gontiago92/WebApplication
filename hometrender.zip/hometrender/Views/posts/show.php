<div class="pageContent">

    <div class="box">
        <div class="box-header"><?= $post->title ?></div>
        <div class="box-content">

            <?= $post->content ?>

            <hr>

            <?php if(count($comments) > 0): ?>

                <h2><?= count($comments) ?> Comments</h2>

            <?php else: ?>
                <h2>There are no comments yet. Add your own !</h2>
            <?php endif; ?>

            <?php foreach($comments as $comment): ?>
                <h4><?= $comment->author ?></h4>
                <p><?= $comment->message ?></p>
            <?php endforeach; ?>

            <form class="commentForm" action="/comment/create" method="POST">
                <div>
                    <label for="author">Author</label>
                    <input type="text" name="author" id="comment" placeholder="Enter your name">
                </div>

                <div>
                    <label for="comment">Message</label>
                    <textarea name="message" id="comment" cols="30" rows="5" placeholder="Write your message here..." style="resize: none"></textarea>
                </div>

                <input type="hidden" name="article_id" value="<?= $post->id ?>">

                <div>
                    <button type="submit" class="btn btn-primary">Post Comment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<aside class="sidebar">
    <div class="box">
        <div class="box-header">Posts</div>
        <div class="box-body">

            <?php foreach($posts as $post): ?>
                <p><a href="<?= $post->id ?>"><?= $post->title ?></a></p>
            <?php endforeach; ?>
        </div>
    </div>
</aside>

<script>
    /*let form = document.querySelector('.commentForm')

    form.addEventListener('submit', e => {
        e.preventDefault()
        alert('clicked')
    })*/
</script>