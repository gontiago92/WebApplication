let socket = io();

socket.on('connected', (data) => {
    document.querySelector('.online_players .box-body').innerHTML = data.online
})

socket.on('disconnected', (data) => {
    document.querySelector('.online_players .box-body').innerHTML = data.online
})