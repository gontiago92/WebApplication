let nav = document.querySelector('nav')
let navicon = document.querySelector('.navicon')
let wrapper = document.querySelector('.wrapper')

navicon.addEventListener('click', (e) => {
    e.preventDefault()
    
    if(wrapper.classList.contains('active')){
        navicon.classList.remove('active')
        wrapper.classList.remove('active')
        nav.classList.remove('active')
    } else {
        navicon.classList.add('active')
        wrapper.classList.add('active')
        nav.classList.add('active')
    }
    
})